
const { getQuiz } = require('../Controllers/QuizController');
const QuizClass = require('../Models/QuizClassModel');
const Quiz = require('../Models/QuizModel');



const quizService = {
    

    async getAllQuizClass() {
        try {
            const quizClasses = await QuizClass.findAll(); 
            if(quizClasses==null){
                return null;
            }
            return quizClasses;
            
        } catch (error) {
            console.error('Error fetching quiz classes:', error);
            throw error;
        }
        
    },


    async getQuizzes(QuizClassId){
        try {
            const quizzes = await Quiz.findAll({
                where: { quizClassId: QuizClassId } 
            });
    
        
            if (quizzes.length === 0) {
                return []; 
            }
    
            return quizzes; 
    
        } catch (error) {
            console.error('Error fetching quizzes:', error);
            throw error; 
        }
    },


    async createUser(userData) {
        const user = new Quiz(userData);
        return await user.save();
    },
    

    async updateUser(userId, userData) {
        return await Quiz.update(userData, { where: { id: userId } });
    },

    async deleteUser(userId) {
        return await Quiz.destroy({ where: { id: userId } });
    },
};

module.exports = quizService;
